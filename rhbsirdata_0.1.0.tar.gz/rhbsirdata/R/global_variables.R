# Declare global variables to avoid R CMD check notes
globalVariables(c("ID", "year", "Expenditure", "Income", "."))
